import React from 'react'
import { Link } from 'react-router-dom';

function Visual({ setSelectedMenu }) {
  const handling = (menu) => {
    setSelectedMenu(menu);
  }
  return (
    <figure id='visual'>
      <Link to="/department" onClick={() => { handling("menu1") }}>menu1</Link>
      <Link to="/department" onClick={() => { handling("menu2") }}>menu2</Link>
      <Link to="/department" onClick={() => { handling("menu3") }}>menu3</Link>
      <Link to="/department" onClick={() => { handling("menu4") }}>menu4</Link>
    </figure>
  )
}

export default Visual