import React from 'react'
import Layout from '../common/Layout'
import { useState } from 'react';
function Department({ selectedMenu }) {
  const [selectedTab, setSelectedTab] = useState(selectedMenu || "menu1");

  const handlingTab = (menu) => {
    setSelectedTab(menu);
  }
  return (
    <Layout name={"Department"}>
      <main>
        <nav>
          <h1>탭</h1>
          <ul>
            <li className={selectedTab === "menu1" ? "on" : ""} onClick={() => handlingTab("menu1")}>menu1</li>
            <li className={selectedTab === "menu2" ? "on" : ""} onClick={() => handlingTab("menu2")}>menu2</li>
            <li className={selectedTab === "menu3" ? "on" : ""} onClick={() => handlingTab("menu3")}>menu3</li>
            <li className={selectedTab === "menu4" ? "on" : ""} onClick={() => handlingTab("menu4")}>menu4</li>
          </ul>
        </nav>
        <section>
          <article className={selectedTab === "menu1" ? "on" : ""}>1</article>
          <article className={selectedTab === "menu2" ? "on" : ""}>2</article>
          <article className={selectedTab === "menu3" ? "on" : ""}>3</article>
          <article className={selectedTab === "menu4" ? "on" : ""}>4</article>
        </section>
      </main>
    </Layout>
  )
}

export default Department