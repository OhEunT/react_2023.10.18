import React from 'react'
import Layout from '../common/Layout'

function Members() {
    return (
        <Layout name={"Members"}>
            <p>Members</p>
        </Layout>
    )
}

export default Members