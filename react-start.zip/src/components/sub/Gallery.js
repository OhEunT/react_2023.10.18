import React from 'react'
import Layout from '../common/Layout'

function Gallery() {
  return (
    <Layout name={"Gallery"}>
      <p>Gallery</p>
    </Layout>
  )
}

export default Gallery