import React from 'react'
import Layout from '../common/Layout'

function Community() {
  return (
    <Layout name={"Community"}>
      <p>Community</p>
    </Layout>
  )
}

export default Community