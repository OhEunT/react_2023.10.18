import React from 'react'
import Layout from '../common/Layout'

function Youtube() {
  return (
    <Layout name={"Youtube"}>
      <p>Youtube</p>
    </Layout>
  )
}

export default Youtube