import React from 'react'
import Layout from '../common/Layout'

function Location() {
  return (
    <Layout name={"Location"}>
      <p>Location</p>
    </Layout>
  )
}

export default Location